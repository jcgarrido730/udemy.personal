public final class ClaseFinal {

    //Variables marcadas como finales
    public static final int VAR_PRIMITIVO = 10;

    public static final Persona VAR_PERSONA = new Persona();

    //metodo final, lo estudiaremos a detalle en el tema de sobreescritura
    public final void metodoFinal(){

    }

}

//class Hija extends ClaseFinal{
//    public final void metodoFinal(){
//    }
//}